import { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import AuthPage from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import CategorySelect from "./pages/CategorySelect";
import TopicSelect from "./pages/TopicSelect";
import InterviewPage from "./pages/InterviewPage";
import Results from "./pages/Results";

const queryClient = new QueryClient();

interface User {
  name: string;
  email: string;
}

interface FeedbackEntry {
  topic: string;
  score: number;
  date: string;
  category: string;
}

const App = () => {
  const [user, setUser] = useState<User | null>(null);
  const [feedback, setFeedback] = useState<FeedbackEntry[]>([]);

  // Load user from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem("ip_user");
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch {}
    }
    const storedFeedback = localStorage.getItem("ip_feedback");
    if (storedFeedback) {
      try {
        setFeedback(JSON.parse(storedFeedback));
      } catch {}
    }
  }, []);

  const handleLogin = (u: User) => {
    setUser(u);
    localStorage.setItem("ip_user", JSON.stringify(u));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("ip_user");
  };

  const handleInterviewComplete = (result: FeedbackEntry) => {
    const updated = [...feedback, result];
    setFeedback(updated);
    localStorage.setItem("ip_feedback", JSON.stringify(updated));
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route
              path="/login"
              element={user ? <Navigate to="/dashboard" replace /> : <AuthPage onLogin={handleLogin} />}
            />
            <Route
              path="/dashboard"
              element={
                user ? (
                  <Dashboard user={user} onLogout={handleLogout} feedback={feedback} />
                ) : (
                  <Navigate to="/login" replace />
                )
              }
            />
            <Route
              path="/category"
              element={user ? <CategorySelect /> : <Navigate to="/login" replace />}
            />
            <Route
              path="/topic/:categoryId"
              element={user ? <TopicSelect /> : <Navigate to="/login" replace />}
            />
            <Route
              path="/interview/:topicId"
              element={
                user ? (
                  <InterviewPage onComplete={handleInterviewComplete} />
                ) : (
                  <Navigate to="/login" replace />
                )
              }
            />
            <Route
              path="/results"
              element={user ? <Results /> : <Navigate to="/login" replace />}
            />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
