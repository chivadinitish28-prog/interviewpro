import { useNavigate } from "react-router-dom";
import {
  Brain, TrendingUp, Clock, Flame, Target, Plus,
  ChevronRight, Star, Download, LogOut, Trophy,
} from "lucide-react";

interface DashboardProps {
  user: { name: string; email: string };
  onLogout: () => void;
  feedback: { topic: string; score: number; date: string; category: string }[];
}

const Dashboard = ({ user, onLogout, feedback }: DashboardProps) => {
  const navigate = useNavigate();

  const totalQuestions = feedback.length * 5;
  const avgScore = feedback.length
    ? Math.round(feedback.reduce((acc, f) => acc + f.score, 0) / feedback.length * 10) / 10
    : 0;
  const timePracticed = feedback.length * 10;
  const streak = feedback.length > 0 ? Math.min(feedback.length, 7) : 0;

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-emerald-400";
    if (score >= 6) return "text-cyan-400";
    if (score >= 4) return "text-yellow-400";
    return "text-red-400";
  };

  const getScoreLabel = (score: number) => {
    if (score >= 8) return "Excellent";
    if (score >= 6) return "Good";
    if (score >= 4) return "Average";
    return "Needs Work";
  };

  const handleDownload = () => {
    const content = [
      "InterviewPro - Performance Report",
      "=".repeat(40),
      `User: ${user.name}`,
      `Email: ${user.email}`,
      `Generated: ${new Date().toLocaleDateString()}`,
      "",
      "STATS",
      "-".repeat(20),
      `Questions Answered: ${totalQuestions}`,
      `Average Score: ${avgScore}/10`,
      `Time Practiced: ${timePracticed} min`,
      `Streak: ${streak} days`,
      "",
      "INTERVIEW HISTORY",
      "-".repeat(20),
      ...feedback.map((f) => `${f.date} | ${f.topic} (${f.category}) | Score: ${f.score}/10`),
    ].join("\n");
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "InterviewPro_Report.txt";
    a.click();
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Top Nav */}
      <nav className="glass border-b border-border/30 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl font-bold gradient-text">InterviewPro</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="text-sm font-semibold">{user.name}</div>
              <div className="text-xs text-muted-foreground">{user.email}</div>
            </div>
            <div className="w-9 h-9 rounded-full bg-gradient-primary flex items-center justify-center font-bold text-sm text-primary-foreground">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <button
              onClick={onLogout}
              className="glass glass-hover p-2 rounded-lg text-muted-foreground hover:text-foreground transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Welcome */}
        <div className="mb-8 slide-up">
          <h1 className="font-display text-3xl font-bold mb-1">
            Welcome back, <span className="gradient-text">{user.name.split(" ")[0]}</span> 👋
          </h1>
          <p className="text-muted-foreground">Track your interview performance and keep improving.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Target, label: "Questions Answered", value: totalQuestions.toString(), sub: "across all interviews", color: "text-primary" },
            { icon: TrendingUp, label: "Average Score", value: `${avgScore}/10`, sub: "performance rating", color: "text-cyan-400" },
            { icon: Clock, label: "Time Practiced", value: `${timePracticed}m`, sub: "total practice time", color: "text-yellow-400" },
            { icon: Flame, label: "Daily Streak", value: `${streak}🔥`, sub: "consecutive days", color: "text-orange-400" },
          ].map((stat) => (
            <div key={stat.label} className="glass glass-hover rounded-2xl p-5 slide-up">
              <div className="flex items-center gap-2 mb-3">
                <stat.icon className={`w-4 h-4 ${stat.color}`} />
                <span className="text-xs text-muted-foreground font-medium">{stat.label}</span>
              </div>
              <div className={`font-display text-2xl font-bold ${stat.color}`}>{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{stat.sub}</div>
            </div>
          ))}
        </div>

        {/* Main content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Feedback History */}
          <div className="lg:col-span-2">
            <div className="glass rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display font-bold text-xl">Interview History</h2>
                {feedback.length > 0 && (
                  <button
                    onClick={handleDownload}
                    className="flex items-center gap-2 glass glass-hover px-3 py-2 rounded-lg text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download Report
                  </button>
                )}
              </div>

              {feedback.length === 0 ? (
                <div className="text-center py-16">
                  <Trophy className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                  <p className="text-muted-foreground font-medium">No interviews yet</p>
                  <p className="text-muted-foreground/60 text-sm mt-1">Start your first interview to see results here</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {[...feedback].reverse().map((f, i) => (
                    <div key={i} className="flex items-center justify-between glass rounded-xl px-4 py-3 glass-hover">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-gradient-primary/20 border border-primary/20 flex items-center justify-center text-sm">
                          {f.category === "technical" ? "💻" : f.category === "hr" ? "👥" : "🛠"}
                        </div>
                        <div>
                          <div className="font-medium text-sm">{f.topic}</div>
                          <div className="text-xs text-muted-foreground">{f.category} · {f.date}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-display font-bold text-lg ${getScoreColor(f.score)}`}>{f.score}/10</div>
                        <div className={`text-xs ${getScoreColor(f.score)}`}>{getScoreLabel(f.score)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right Panel */}
          <div className="space-y-4">
            {/* Start New Interview */}
            <div className="glass rounded-2xl p-6 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/5 rounded-2xl" />
              <div className="relative">
                <Star className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-display font-bold text-lg mb-2">Ready to Practice?</h3>
                <p className="text-muted-foreground text-sm mb-4">Choose a category and start a new interview session.</p>
                <button
                  onClick={() => navigate("/category")}
                  className="w-full btn-primary flex items-center justify-center gap-2 py-3 rounded-xl text-primary-foreground font-semibold text-sm"
                >
                  <Plus className="w-4 h-4" />
                  Start New Interview
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Performance Summary */}
            {feedback.length > 0 && (
              <div className="glass rounded-2xl p-6">
                <h3 className="font-display font-semibold mb-4">Performance by Category</h3>
                {(["technical", "hr", "general"] as const).map((cat) => {
                  const catFeedback = feedback.filter((f) => f.category === cat);
                  if (!catFeedback.length) return null;
                  const avg = Math.round(catFeedback.reduce((a, f) => a + f.score, 0) / catFeedback.length * 10) / 10;
                  const pct = (avg / 10) * 100;
                  return (
                    <div key={cat} className="mb-4 last:mb-0">
                      <div className="flex justify-between text-sm mb-1.5">
                        <span className="capitalize font-medium">{cat === "hr" ? "HR & General" : cat}</span>
                        <span className={`font-bold ${getScoreColor(avg)}`}>{avg}/10</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full progress-bar-fill transition-all duration-700"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Quick Tips */}
            <div className="glass rounded-2xl p-5">
              <h3 className="font-display font-semibold mb-3 text-sm">💡 Pro Tips</h3>
              <ul className="space-y-2">
                {[
                  "Use specific keywords in your answers",
                  "Practice daily to build your streak",
                  "Review all three domains for balance",
                ].map((tip) => (
                  <li key={tip} className="text-xs text-muted-foreground flex items-start gap-2">
                    <span className="text-primary mt-0.5">→</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
