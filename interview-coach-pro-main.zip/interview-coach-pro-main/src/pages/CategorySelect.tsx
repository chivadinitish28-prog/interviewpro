import { useNavigate } from "react-router-dom";
import { categories } from "@/data/questions";
import { Brain, ArrowLeft, ChevronRight } from "lucide-react";

const CategorySelect = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <nav className="glass border-b border-border/30 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="glass glass-hover p-2 rounded-lg text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            <span className="font-display font-bold gradient-text">InterviewPro</span>
          </div>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-6 py-16 slide-up">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full text-sm text-primary mb-4">
            Step 1 of 3 — Choose Category
          </div>
          <h1 className="font-display text-4xl font-bold mb-3">
            What type of interview do you want to <span className="gradient-text">practice?</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-lg mx-auto">
            Select a domain that matches your target interview
          </p>
        </div>

        {/* Category Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((cat, i) => (
            <button
              key={cat.id}
              onClick={() => navigate(`/topic/${cat.id}`)}
              className="glass glass-hover rounded-2xl p-8 text-left group transition-all duration-300 border border-border/30 hover:border-primary/40 fade-in"
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              {/* Icon */}
              <div className="text-5xl mb-5">{cat.icon}</div>
              
              {/* Badge */}
              <div className={`inline-flex text-xs font-semibold px-3 py-1 rounded-full bg-gradient-to-r ${cat.color} text-white mb-4`}>
                {cat.label}
              </div>

              <h3 className="font-display text-xl font-bold mb-2">{cat.label}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">{cat.description}</p>

              <div className="flex items-center gap-2 text-sm text-primary font-medium group-hover:gap-3 transition-all">
                Select this track
                <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </div>
            </button>
          ))}
        </div>

        {/* Info */}
        <div className="mt-12 glass rounded-2xl p-6 flex items-start gap-4">
          <span className="text-2xl">💡</span>
          <div>
            <p className="font-medium text-sm mb-1">Not sure which to pick?</p>
            <p className="text-muted-foreground text-sm">
              Start with <strong className="text-foreground">Beginner</strong> if you're just getting started, 
              <strong className="text-foreground"> Technical</strong> for coding roles, or 
              <strong className="text-foreground"> HR & General</strong> for behavioral interviews.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategorySelect;
