import { useNavigate } from "react-router-dom";
import heroBg from "@/assets/hero-bg.jpg";
import { Brain, Target, TrendingUp, Shield, ArrowRight, CheckCircle2, Zap, Star } from "lucide-react";

const features = [
  { icon: Brain, title: "AI-Powered Questions", desc: "Dynamic question selection tailored to your chosen topic and difficulty" },
  { icon: Target, title: "Keyword Scoring", desc: "Intelligent answer evaluation using keyword matching algorithm" },
  { icon: TrendingUp, title: "Performance Analytics", desc: "Track your progress with detailed dashboard and feedback history" },
  { icon: Shield, title: "Multiple Domains", desc: "Technical, HR & behavioral, and beginner-friendly interview tracks" },
];

const stats = [
  { label: "Questions Available", value: "80+" },
  { label: "Interview Topics", value: "9" },
  { label: "Skill Domains", value: "3" },
  { label: "Users Practicing", value: "1K+" },
];

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/30">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl font-bold gradient-text">InterviewPro</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/login")}
              className="text-muted-foreground hover:text-foreground transition-colors text-sm font-medium"
            >
              Sign In
            </button>
            <button
              onClick={() => navigate("/login")}
              className="btn-primary px-4 py-2 rounded-lg text-sm font-semibold text-primary-foreground"
            >
              Get Started
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20">
        {/* Background image */}
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: `url(${heroBg})` }}
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/60 to-background" />
        {/* Animated orbs */}
        <div className="absolute top-1/4 left-1/4 w-80 h-80 rounded-full bg-primary/10 blur-[120px] animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 rounded-full bg-accent/10 blur-[100px] animate-float" style={{ animationDelay: "1.5s" }} />

        <div className="relative max-w-6xl mx-auto px-6 py-24 text-center slide-up">
          <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full text-sm text-primary mb-6 font-medium">
            <Zap className="w-4 h-4" />
            AI-Powered Interview Preparation
          </div>
          <h1 className="font-display text-5xl md:text-7xl font-bold leading-tight mb-6">
            Ace Every{" "}
            <span className="gradient-text">Interview</span>
            <br />
            With Confidence
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Practice mock interviews across Technical, HR, and Beginner tracks. Get instant AI-powered feedback and track your performance growth.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate("/login")}
              className="btn-primary flex items-center gap-2 px-8 py-4 rounded-xl text-primary-foreground font-semibold text-lg group"
            >
              Start Practicing Free
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
            <button
              onClick={() => navigate("/login")}
              className="glass glass-hover px-8 py-4 rounded-xl text-foreground font-semibold text-lg"
            >
              View Dashboard
            </button>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-20 max-w-3xl mx-auto">
            {stats.map((stat) => (
              <div key={stat.label} className="glass rounded-xl p-4 text-center">
                <div className="font-display text-2xl font-bold gradient-text">{stat.value}</div>
                <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-16 fade-in">
          <h2 className="font-display text-4xl font-bold mb-4">
            Everything You Need to <span className="gradient-text">Succeed</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            A complete interview preparation ecosystem designed for modern job seekers
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((f, i) => (
            <div key={f.title} className="glass glass-hover rounded-2xl p-6 flex gap-5 fade-in" style={{ animationDelay: `${i * 0.1}s` }}>
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center flex-shrink-0 shadow-primary">
                <f.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-lg mb-1">{f.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl font-bold mb-4">How It <span className="gradient-text">Works</span></h2>
          </div>
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-accent to-transparent hidden md:block" />
            {[
              { step: "01", title: "Create Your Account", desc: "Sign up for free and set up your profile in seconds." },
              { step: "02", title: "Choose Your Domain", desc: "Select from Technical, HR, or Beginner interview tracks." },
              { step: "03", title: "Pick a Topic", desc: "Narrow down to specific languages or subjects you want to practice." },
              { step: "04", title: "Take the Interview", desc: "Answer 5 randomly selected questions and submit your responses." },
              { step: "05", title: "Get Scored & Improve", desc: "Receive instant scores and feedback. Track your progress on the dashboard." },
            ].map((step, i) => (
              <div key={step.step} className="flex gap-8 mb-10 items-start fade-in" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="w-16 h-16 rounded-full glass flex items-center justify-center flex-shrink-0 font-display font-bold text-primary text-sm border border-primary/30 pulse-glow">
                  {step.step}
                </div>
                <div className="glass rounded-2xl p-5 flex-1 glass-hover">
                  <h3 className="font-display font-semibold text-lg mb-1">{step.title}</h3>
                  <p className="text-muted-foreground text-sm">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6">
        <div className="max-w-3xl mx-auto text-center glass rounded-3xl p-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/5 rounded-3xl" />
          <div className="relative">
            <Star className="w-12 h-12 text-primary mx-auto mb-4" />
            <h2 className="font-display text-4xl font-bold mb-4">Ready to Crush Your Next Interview?</h2>
            <p className="text-muted-foreground mb-8 text-lg">Join thousands of candidates who aced their interviews with InterviewPro.</p>
            <div className="flex items-center justify-center gap-6 mb-8 text-sm text-muted-foreground">
              {["Free to start", "No credit card", "Instant feedback"].map((item) => (
                <div key={item} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  {item}
                </div>
              ))}
            </div>
            <button
              onClick={() => navigate("/login")}
              className="btn-primary px-10 py-4 rounded-xl text-primary-foreground font-bold text-lg"
            >
              Start Your Free Practice
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 text-center border-t border-border/30 text-muted-foreground text-sm">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Brain className="w-4 h-4 text-primary" />
          <span className="font-display font-bold gradient-text">InterviewPro</span>
        </div>
        <p>© 2026 InterviewPro. Built for aspiring professionals.</p>
      </footer>
    </div>
  );
};

export default Index;
