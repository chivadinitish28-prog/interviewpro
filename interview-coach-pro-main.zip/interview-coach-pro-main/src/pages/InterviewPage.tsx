import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { pickRandomQuestions, scoreAnswer, topics } from "@/data/questions";
import type { Question } from "@/data/questions";
import { Brain, ArrowLeft, ChevronRight, Clock } from "lucide-react";

interface InterviewPageProps {
  onComplete: (result: { topic: string; category: string; score: number; date: string }) => void;
}

const InterviewPage = ({ onComplete }: InterviewPageProps) => {
  const { topicId } = useParams<{ topicId: string }>();
  const navigate = useNavigate();

  const [questions, setQuestions] = useState<Question[]>([]);
  const [current, setCurrent] = useState(0);
  const [answer, setAnswer] = useState("");
  const [scores, setScores] = useState<number[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120);

  const topic = topics.find((t) => t.id === topicId);

  useEffect(() => {
    if (topicId) {
      setQuestions(pickRandomQuestions(topicId, 5));
    }
  }, [topicId]);

  useEffect(() => {
    if (submitted) return;
    const t = setInterval(() => setTimeLeft((prev) => Math.max(prev - 1, 0)), 1000);
    return () => clearInterval(t);
  }, [submitted, current]);

  useEffect(() => {
    setTimeLeft(120);
  }, [current]);

  if (!topic || questions.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-muted-foreground">Loading interview...</div>
      </div>
    );
  }

  const currentQ = questions[current];
  const progress = ((current) / questions.length) * 100;

  const handleSubmit = () => {
    const score = scoreAnswer(answer, currentQ.keywords);
    const newScores = [...scores, score];
    setScores(newScores);
    setSubmitted(true);
  };

  const handleNext = () => {
    if (current + 1 >= questions.length) {
      // Interview complete
      const finalScores = [...scores];
      const totalScore = Math.round(finalScores.reduce((a, b) => a + b, 0) / finalScores.length * 10) / 10;
      const result = {
        topic: topic.label,
        category: topic.categoryId,
        score: totalScore,
        date: new Date().toLocaleDateString(),
      };
      onComplete(result);
      navigate(`/results`, { state: { scores: finalScores, questions, topicId, topic: topic.label } });
    } else {
      setCurrent(current + 1);
      setAnswer("");
      setSubmitted(false);
    }
  };

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  const timeColor = timeLeft < 30 ? "text-red-400" : timeLeft < 60 ? "text-yellow-400" : "text-cyan-400";

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <nav className="glass border-b border-border/30 sticky top-0 z-50">
        <div className="max-w-3xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/dashboard")}
              className="glass glass-hover p-2 rounded-lg text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              <span className="font-display font-bold gradient-text">{topic.label} Interview</span>
            </div>
          </div>
          <div className={`flex items-center gap-2 glass px-3 py-1.5 rounded-lg font-mono text-sm font-bold ${timeColor}`}>
            <Clock className="w-3.5 h-3.5" />
            {formatTime(timeLeft)}
          </div>
        </div>
        {/* Progress bar */}
        <div className="h-1 bg-muted">
          <div
            className="h-full progress-bar-fill transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </nav>

      <div className="max-w-3xl mx-auto px-6 py-10 slide-up">
        {/* Question Counter */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            {questions.map((_, i) => (
              <div
                key={i}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  i < current
                    ? "bg-gradient-primary text-primary-foreground"
                    : i === current
                    ? "glass border-2 border-primary text-primary"
                    : "glass border border-border text-muted-foreground"
                }`}
              >
                {i + 1}
              </div>
            ))}
          </div>
          <div className="text-sm text-muted-foreground">
            Question <span className="text-foreground font-semibold">{current + 1}</span> / {questions.length}
          </div>
        </div>

        {/* Question Card */}
        <div className="glass rounded-2xl p-8 mb-6 border border-border/30 fade-in" key={current}>
          <div className="flex items-center gap-2 text-xs text-primary font-medium mb-4">
            <span className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center text-primary">{current + 1}</span>
            Interview Question
          </div>
          <h2 className="font-display text-xl font-bold leading-relaxed">{currentQ.question}</h2>
        </div>

        {/* Answer Area */}
        <div className="glass rounded-2xl p-6 border border-border/30">
          <label className="text-sm font-medium text-muted-foreground mb-3 block">Your Answer</label>
          <textarea
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            disabled={submitted}
            placeholder="Type your answer here. Be specific and use relevant technical terms..."
            rows={6}
            className="w-full bg-muted/30 border border-border/50 rounded-xl p-4 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 resize-none transition-all disabled:opacity-60"
          />

          {/* Submitted feedback */}
          {submitted && (
            <div className="mt-4 p-4 glass rounded-xl border border-primary/20 fade-in">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-primary">Keywords to look for:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {currentQ.keywords.map((kw) => {
                  const matched = answer.toLowerCase().includes(kw.toLowerCase());
                  return (
                    <span
                      key={kw}
                      className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                        matched
                          ? "bg-emerald-400/20 text-emerald-400 border border-emerald-400/30"
                          : "bg-muted/50 text-muted-foreground border border-border"
                      }`}
                    >
                      {matched ? "✓" : "○"} {kw}
                    </span>
                  );
                })}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 mt-5">
            {!submitted ? (
              <button
                onClick={handleSubmit}
                disabled={!answer.trim()}
                className="btn-primary px-6 py-2.5 rounded-xl text-primary-foreground font-semibold text-sm disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Submit Answer
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="btn-primary flex items-center gap-2 px-6 py-2.5 rounded-xl text-primary-foreground font-semibold text-sm"
              >
                {current + 1 >= questions.length ? "See Results" : "Next Question"}
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InterviewPage;
