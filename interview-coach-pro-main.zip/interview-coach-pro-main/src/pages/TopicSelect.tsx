import { useNavigate, useParams } from "react-router-dom";
import { topics, categories } from "@/data/questions";
import { Brain, ArrowLeft, ChevronRight, Lock } from "lucide-react";

const TopicSelect = () => {
  const navigate = useNavigate();
  const { categoryId } = useParams<{ categoryId: string }>();

  const category = categories.find((c) => c.id === categoryId);
  const filteredTopics = topics.filter((t) => t.categoryId === categoryId);

  if (!category) {
    navigate("/category");
    return null;
  }

  const topicEmojis: Record<string, string> = {
    python: "🐍",
    java: "☕",
    javascript: "🟨",
    cpp: "⚡",
    c: "🔧",
    hr_general: "🤝",
    html: "📄",
    css: "🎨",
    js_basics: "📜",
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <nav className="glass border-b border-border/30 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center gap-4">
          <button
            onClick={() => navigate("/category")}
            className="glass glass-hover p-2 rounded-lg text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            <span className="font-display font-bold gradient-text">InterviewPro</span>
          </div>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-6 py-16 slide-up">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full text-sm text-primary mb-4">
            Step 2 of 3 — Select Topic
          </div>
          <div className="text-4xl mb-3">{category.icon}</div>
          <h1 className="font-display text-4xl font-bold mb-3">
            Choose a <span className="gradient-text">{category.label}</span> Topic
          </h1>
          <p className="text-muted-foreground text-lg max-w-lg mx-auto">
            Select the specific subject you want to practice
          </p>
        </div>

        {/* Topic Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 max-w-3xl mx-auto">
          {filteredTopics.map((topic, i) => (
            <button
              key={topic.id}
              onClick={() => navigate(`/interview/${topic.id}`)}
              className="glass glass-hover rounded-2xl p-6 text-left group border border-border/30 hover:border-primary/40 transition-all duration-300 fade-in"
              style={{ animationDelay: `${i * 0.07}s` }}
            >
              <div className="text-3xl mb-3">{topicEmojis[topic.id] || "📚"}</div>
              <h3 className="font-display font-bold text-lg mb-1">{topic.label}</h3>
              <div className="flex items-center gap-1 text-xs text-primary mt-3 font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                Start Interview
                <ChevronRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </button>
          ))}
        </div>

        {/* Info bar */}
        <div className="mt-12 glass rounded-2xl p-5 flex items-center justify-between">
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <Lock className="w-4 h-4 text-primary" />
            <span>Each interview has <strong className="text-foreground">5 randomly selected questions</strong> from a large question pool</span>
          </div>
          <div className="text-xs glass px-3 py-1.5 rounded-full text-primary font-medium hidden sm:block">
            ~10 min session
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopicSelect;
