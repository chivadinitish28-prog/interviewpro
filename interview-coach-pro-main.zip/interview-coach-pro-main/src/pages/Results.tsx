import { useLocation, useNavigate } from "react-router-dom";
import { getPerformanceLevel, scoreAnswer } from "@/data/questions";
import type { Question } from "@/data/questions";
import { Brain, Home, RotateCcw, Trophy, CheckCircle2, XCircle } from "lucide-react";

interface LocationState {
  scores: number[];
  questions: Question[];
  topicId: string;
  topic: string;
}

const Results = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as LocationState | null;

  if (!state) {
    navigate("/dashboard");
    return null;
  }

  const { scores, questions, topic } = state;
  const totalScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length * 10) / 10;
  const performance = getPerformanceLevel(totalScore);
  const pct = Math.round((totalScore / 10) * 100);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <nav className="glass border-b border-border/30">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center gap-2">
          <Brain className="w-5 h-5 text-primary" />
          <span className="font-display font-bold gradient-text">InterviewPro</span>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-6 py-12 slide-up">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 rounded-full bg-gradient-primary flex items-center justify-center mx-auto mb-6 shadow-glow-lg pulse-glow">
            <Trophy className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="font-display text-4xl font-bold mb-2">Interview Complete!</h1>
          <p className="text-muted-foreground text-lg">{topic} Interview Results</p>
        </div>

        {/* Score Circle */}
        <div className="glass rounded-3xl p-10 mb-8 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 rounded-3xl" />
          <div className="relative">
            {/* Big score display */}
            <div className="relative inline-flex items-center justify-center mb-6">
              <svg className="w-40 h-40 -rotate-90" viewBox="0 0 120 120">
                <circle
                  cx="60" cy="60" r="52"
                  fill="none"
                  stroke="hsl(var(--border))"
                  strokeWidth="8"
                />
                <circle
                  cx="60" cy="60" r="52"
                  fill="none"
                  stroke="url(#scoreGrad)"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${(pct / 100) * 327} 327`}
                  className="transition-all duration-1000"
                />
                <defs>
                  <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#8b5cf6" />
                  <stop offset="100%" stopColor="#a855f7" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute text-center">
                <div className="font-display text-4xl font-bold gradient-text">{totalScore}</div>
                <div className="text-muted-foreground text-sm">/10</div>
              </div>
            </div>

            <div className={`font-display text-2xl font-bold ${performance.color} mb-1`}>
              {performance.emoji} {performance.label}
            </div>
            <p className="text-muted-foreground text-sm">
              You scored <strong className="text-foreground">{pct}%</strong> on your {topic} interview
            </p>

            {/* Quick stats */}
            <div className="flex items-center justify-center gap-8 mt-6 pt-6 border-t border-border/30">
              <div className="text-center">
                <div className="font-display text-xl font-bold text-emerald-400">
                  {scores.filter((s) => s >= 6).length}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">Good Answers</div>
              </div>
              <div className="text-center">
                <div className="font-display text-xl font-bold text-yellow-400">
                  {scores.filter((s) => s >= 4 && s < 6).length}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">Average Answers</div>
              </div>
              <div className="text-center">
                <div className="font-display text-xl font-bold text-red-400">
                  {scores.filter((s) => s < 4).length}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">Needs Work</div>
              </div>
            </div>
          </div>
        </div>

        {/* Per-question breakdown */}
        <div className="glass rounded-2xl p-6 mb-8">
          <h2 className="font-display font-bold text-lg mb-5">Question Breakdown</h2>
          <div className="space-y-4">
            {questions.map((q, i) => {
              const s = scores[i] ?? 0;
              const good = s >= 6;
              const pctQ = Math.round((s / 10) * 100);
              return (
                <div key={i} className="glass rounded-xl p-4 fade-in" style={{ animationDelay: `${i * 0.08}s` }}>
                  <div className="flex items-start gap-3 mb-3">
                    {good
                      ? <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                      : <XCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                    }
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium leading-relaxed">{q.question}</p>
                    </div>
                    <div className={`font-display font-bold text-lg ml-2 flex-shrink-0 ${good ? "text-emerald-400" : s >= 4 ? "text-yellow-400" : "text-red-400"}`}>
                      {s}/10
                    </div>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden ml-8">
                    <div
                      className="h-full progress-bar-fill"
                      style={{ width: `${pctQ}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => navigate("/dashboard")}
            className="flex-1 glass glass-hover flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm"
          >
            <Home className="w-4 h-4" />
            Back to Dashboard
          </button>
          <button
            onClick={() => navigate("/category")}
            className="flex-1 btn-primary flex items-center justify-center gap-2 py-3.5 rounded-xl text-primary-foreground font-semibold text-sm"
          >
            <RotateCcw className="w-4 h-4" />
            Practice Again
          </button>
        </div>
      </div>
    </div>
  );
};

export default Results;
