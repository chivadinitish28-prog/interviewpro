export interface Question {
  id: number;
  question: string;
  keywords: string[];
  hint?: string;
}

export interface Category {
  id: string;
  label: string;
  icon: string;
  description: string;
  color: string;
}

export interface Topic {
  id: string;
  label: string;
  categoryId: string;
}

export const categories: Category[] = [
  {
    id: "technical",
    label: "Technical",
    icon: "💻",
    description: "Coding, algorithms, and language-specific questions",
    color: "from-violet-500 to-purple-700",
  },
  {
    id: "hr",
    label: "HR & General",
    icon: "👥",
    description: "Behavioral, communication, and soft skills questions",
    color: "from-cyan-400 to-blue-600",
  },
  {
    id: "general",
    label: "Beginner",
    icon: "🛠",
    description: "HTML, CSS, JS fundamentals for beginners",
    color: "from-emerald-400 to-teal-600",
  },
];

export const topics: Topic[] = [
  { id: "python", label: "Python", categoryId: "technical" },
  { id: "java", label: "Java", categoryId: "technical" },
  { id: "javascript", label: "JavaScript", categoryId: "technical" },
  { id: "cpp", label: "C++", categoryId: "technical" },
  { id: "c", label: "C", categoryId: "technical" },
  { id: "hr_general", label: "HR Interview", categoryId: "hr" },
  { id: "html", label: "HTML Basics", categoryId: "general" },
  { id: "css", label: "CSS Basics", categoryId: "general" },
  { id: "js_basics", label: "JS Fundamentals", categoryId: "general" },
];

export const questionBank: Record<string, Question[]> = {
  python: [
    {
      id: 1,
      question: "What is a list comprehension in Python and when would you use it?",
      keywords: ["list", "comprehension", "iteration", "concise", "filter", "map", "loop", "expression"],
    },
    {
      id: 2,
      question: "Explain the difference between a tuple and a list in Python.",
      keywords: ["tuple", "list", "mutable", "immutable", "ordered", "sequence", "hashable"],
    },
    {
      id: 3,
      question: "What are decorators in Python? Give an example use case.",
      keywords: ["decorator", "wrapper", "function", "modify", "extend", "logging", "authentication", "higher-order"],
    },
    {
      id: 4,
      question: "What is the difference between `deepcopy` and `copy` in Python?",
      keywords: ["deepcopy", "copy", "shallow", "deep", "nested", "reference", "object", "clone"],
    },
    {
      id: 5,
      question: "Explain Python's GIL (Global Interpreter Lock).",
      keywords: ["GIL", "global interpreter lock", "thread", "concurrency", "CPython", "parallel", "mutex"],
    },
    {
      id: 6,
      question: "What is a generator in Python and how does it differ from a regular function?",
      keywords: ["generator", "yield", "iterator", "lazy", "memory", "efficient", "next", "iterable"],
    },
    {
      id: 7,
      question: "What are Python's magic methods? Name a few with their use cases.",
      keywords: ["magic", "dunder", "__init__", "__str__", "__repr__", "__len__", "special", "method"],
    },
    {
      id: 8,
      question: "Explain how exception handling works in Python.",
      keywords: ["try", "except", "finally", "raise", "exception", "error", "handling", "catch"],
    },
  ],

  java: [
    {
      id: 1,
      question: "What is the difference between an abstract class and an interface in Java?",
      keywords: ["abstract", "interface", "implements", "extends", "multiple", "inheritance", "method", "class"],
    },
    {
      id: 2,
      question: "Explain Java's garbage collection mechanism.",
      keywords: ["garbage", "collection", "JVM", "heap", "memory", "GC", "reference", "automatic"],
    },
    {
      id: 3,
      question: "What is the difference between `==` and `.equals()` in Java?",
      keywords: ["equals", "==", "reference", "value", "object", "comparison", "string", "identity"],
    },
    {
      id: 4,
      question: "Explain the concept of multithreading in Java.",
      keywords: ["thread", "runnable", "synchronized", "concurrent", "parallel", "lock", "wait", "notify"],
    },
    {
      id: 5,
      question: "What are Java Collections? Name some commonly used ones.",
      keywords: ["collection", "ArrayList", "HashMap", "HashSet", "List", "Map", "Set", "LinkedList"],
    },
    {
      id: 6,
      question: "What is polymorphism in Java?",
      keywords: ["polymorphism", "override", "overload", "runtime", "compile", "method", "dynamic", "binding"],
    },
    {
      id: 7,
      question: "Explain the SOLID principles in object-oriented programming.",
      keywords: ["SOLID", "single", "open", "closed", "Liskov", "interface", "dependency", "principle"],
    },
    {
      id: 8,
      question: "What are lambda expressions in Java 8?",
      keywords: ["lambda", "functional", "interface", "stream", "arrow", "expression", "Java 8", "closure"],
    },
  ],

  javascript: [
    {
      id: 1,
      question: "Explain the concept of closures in JavaScript.",
      keywords: ["closure", "scope", "inner", "outer", "function", "variable", "lexical", "encapsulate"],
    },
    {
      id: 2,
      question: "What is the difference between `var`, `let`, and `const`?",
      keywords: ["var", "let", "const", "scope", "hoisting", "block", "reassign", "declaration"],
    },
    {
      id: 3,
      question: "Explain event bubbling and event capturing in JavaScript.",
      keywords: ["bubbling", "capturing", "event", "propagation", "DOM", "parent", "stopPropagation", "target"],
    },
    {
      id: 4,
      question: "What is the JavaScript event loop?",
      keywords: ["event loop", "call stack", "queue", "async", "promise", "microtask", "macrotask", "setTimeout"],
    },
    {
      id: 5,
      question: "What are Promises and async/await in JavaScript?",
      keywords: ["promise", "async", "await", "then", "catch", "asynchronous", "resolve", "reject"],
    },
    {
      id: 6,
      question: "What is prototypal inheritance in JavaScript?",
      keywords: ["prototype", "inheritance", "chain", "object", "__proto__", "class", "extends", "property"],
    },
    {
      id: 7,
      question: "Explain the difference between `null` and `undefined` in JavaScript.",
      keywords: ["null", "undefined", "absence", "declared", "assigned", "type", "empty", "value"],
    },
    {
      id: 8,
      question: "What are higher-order functions in JavaScript?",
      keywords: ["higher-order", "map", "filter", "reduce", "function", "argument", "return", "callback"],
    },
  ],

  cpp: [
    {
      id: 1,
      question: "What is the difference between stack and heap memory in C++?",
      keywords: ["stack", "heap", "memory", "allocation", "dynamic", "static", "pointer", "new"],
    },
    {
      id: 2,
      question: "Explain virtual functions in C++.",
      keywords: ["virtual", "polymorphism", "override", "vtable", "runtime", "base", "derived", "function"],
    },
    {
      id: 3,
      question: "What are pointers and references in C++? What's the difference?",
      keywords: ["pointer", "reference", "address", "dereference", "null", "memory", "alias", "rebind"],
    },
    {
      id: 4,
      question: "What is RAII in C++?",
      keywords: ["RAII", "resource", "acquisition", "initialization", "destructor", "scope", "memory", "smart pointer"],
    },
    {
      id: 5,
      question: "Explain templates in C++.",
      keywords: ["template", "generic", "type", "function", "class", "compile", "specialization", "parameter"],
    },
    {
      id: 6,
      question: "What is the difference between `new` and `malloc` in C++?",
      keywords: ["new", "malloc", "constructor", "destructor", "operator", "cast", "void", "typed"],
    },
    {
      id: 7,
      question: "What is move semantics and `std::move`?",
      keywords: ["move", "rvalue", "lvalue", "semantics", "efficiency", "resource", "transfer", "std::move"],
    },
    {
      id: 8,
      question: "Explain the concept of operator overloading in C++.",
      keywords: ["operator", "overload", "+", "==", "class", "custom", "defined", "symbol"],
    },
  ],

  c: [
    {
      id: 1,
      question: "What is the difference between `malloc`, `calloc`, and `realloc`?",
      keywords: ["malloc", "calloc", "realloc", "memory", "allocate", "initialize", "zero", "resize"],
    },
    {
      id: 2,
      question: "Explain the use of pointers in C.",
      keywords: ["pointer", "address", "dereference", "memory", "variable", "*", "&", "null"],
    },
    {
      id: 3,
      question: "What are structures in C and how are they used?",
      keywords: ["struct", "structure", "member", "compound", "data", "type", "record", "typedef"],
    },
    {
      id: 4,
      question: "What is the difference between `++i` and `i++` in C?",
      keywords: ["prefix", "postfix", "increment", "pre", "post", "value", "return", "++"],
    },
    {
      id: 5,
      question: "Explain file I/O operations in C.",
      keywords: ["fopen", "fclose", "fread", "fwrite", "fgets", "file", "stream", "pointer"],
    },
    {
      id: 6,
      question: "What are header files and why are they used in C?",
      keywords: ["header", ".h", "include", "declaration", "prototype", "library", "stdio", "stdlib"],
    },
    {
      id: 7,
      question: "Explain the difference between `const` and `#define` in C.",
      keywords: ["const", "define", "preprocessor", "type-safe", "macro", "constant", "value", "compilation"],
    },
    {
      id: 8,
      question: "What is a linked list and how is it implemented in C?",
      keywords: ["linked list", "node", "pointer", "next", "head", "tail", "dynamic", "struct"],
    },
  ],

  hr_general: [
    {
      id: 1,
      question: "Tell me about yourself and your background.",
      keywords: ["experience", "background", "skills", "education", "passion", "goal", "professional", "worked"],
    },
    {
      id: 2,
      question: "Describe a challenge you faced at work and how you overcame it.",
      keywords: ["challenge", "problem", "solution", "overcome", "approach", "team", "result", "learned"],
    },
    {
      id: 3,
      question: "Why do you want to work for this company?",
      keywords: ["company", "culture", "values", "growth", "opportunity", "mission", "product", "excited"],
    },
    {
      id: 4,
      question: "Where do you see yourself in 5 years?",
      keywords: ["goals", "future", "career", "grow", "leadership", "skills", "develop", "ambition"],
    },
    {
      id: 5,
      question: "What are your greatest strengths?",
      keywords: ["strength", "skill", "problem-solving", "communication", "leadership", "analytical", "teamwork", "example"],
    },
    {
      id: 6,
      question: "How do you handle working under pressure or tight deadlines?",
      keywords: ["pressure", "deadline", "prioritize", "organize", "calm", "manage", "time", "focus"],
    },
    {
      id: 7,
      question: "Describe a time you worked as part of a team.",
      keywords: ["team", "collaborate", "cooperate", "contribute", "role", "member", "project", "together"],
    },
    {
      id: 8,
      question: "What motivates you to do your best work?",
      keywords: ["motivation", "passion", "challenge", "learning", "impact", "growth", "achieve", "goal"],
    },
  ],

  html: [
    {
      id: 1,
      question: "What is the difference between `<div>` and `<span>` in HTML?",
      keywords: ["div", "span", "block", "inline", "display", "container", "element", "layout"],
    },
    {
      id: 2,
      question: "Explain semantic HTML and why it matters.",
      keywords: ["semantic", "header", "footer", "article", "section", "nav", "accessibility", "SEO"],
    },
    {
      id: 3,
      question: "What is the purpose of the `<!DOCTYPE html>` declaration?",
      keywords: ["doctype", "declaration", "html5", "browser", "render", "mode", "standards", "document"],
    },
    {
      id: 4,
      question: "How do HTML forms work? Name some common input types.",
      keywords: ["form", "input", "text", "submit", "action", "method", "type", "label"],
    },
    {
      id: 5,
      question: "What is the difference between `href` and `src` attributes?",
      keywords: ["href", "src", "link", "image", "attribute", "resource", "anchor", "script"],
    },
    {
      id: 6,
      question: "What are HTML data attributes and when are they used?",
      keywords: ["data", "attribute", "custom", "data-*", "JavaScript", "DOM", "store", "element"],
    },
    {
      id: 7,
      question: "Explain the HTML table structure.",
      keywords: ["table", "tr", "td", "th", "thead", "tbody", "tfoot", "row", "column"],
    },
    {
      id: 8,
      question: "What is the difference between `<script>` tag placement in head vs body?",
      keywords: ["script", "head", "body", "defer", "async", "loading", "blocking", "DOM"],
    },
  ],

  css: [
    {
      id: 1,
      question: "Explain the CSS box model.",
      keywords: ["box model", "margin", "padding", "border", "content", "width", "height", "area"],
    },
    {
      id: 2,
      question: "What is the difference between Flexbox and CSS Grid?",
      keywords: ["flexbox", "grid", "layout", "one-dimensional", "two-dimensional", "display", "container", "axis"],
    },
    {
      id: 3,
      question: "What is CSS specificity and how does it work?",
      keywords: ["specificity", "selector", "id", "class", "element", "priority", "override", "cascade"],
    },
    {
      id: 4,
      question: "Explain the difference between `position: relative`, `absolute`, `fixed`, and `sticky`.",
      keywords: ["position", "relative", "absolute", "fixed", "sticky", "flow", "document", "offset"],
    },
    {
      id: 5,
      question: "What are CSS custom properties (variables)?",
      keywords: ["variable", "custom property", "--", "var()", "reuse", "theme", "dynamic", "root"],
    },
    {
      id: 6,
      question: "How do CSS media queries work?",
      keywords: ["media query", "responsive", "breakpoint", "screen", "width", "mobile", "tablet", "desktop"],
    },
    {
      id: 7,
      question: "What are CSS pseudo-classes and pseudo-elements?",
      keywords: ["pseudo-class", "pseudo-element", ":hover", "::before", "::after", "state", "selector", "style"],
    },
    {
      id: 8,
      question: "Explain CSS animations and transitions.",
      keywords: ["animation", "transition", "keyframe", "duration", "ease", "transform", "property", "smooth"],
    },
  ],

  js_basics: [
    {
      id: 1,
      question: "What is the difference between `==` and `===` in JavaScript?",
      keywords: ["==", "===", "strict", "equality", "type", "coercion", "compare", "value"],
    },
    {
      id: 2,
      question: "What are the data types in JavaScript?",
      keywords: ["string", "number", "boolean", "null", "undefined", "object", "symbol", "BigInt", "type"],
    },
    {
      id: 3,
      question: "Explain what `undefined` and `null` mean in JavaScript.",
      keywords: ["undefined", "null", "absence", "declared", "assigned", "empty", "value", "difference"],
    },
    {
      id: 4,
      question: "What is hoisting in JavaScript?",
      keywords: ["hoisting", "var", "function", "declaration", "scope", "top", "initialization", "moved"],
    },
    {
      id: 5,
      question: "What is a callback function in JavaScript?",
      keywords: ["callback", "function", "argument", "pass", "asynchronous", "execute", "later", "event"],
    },
    {
      id: 6,
      question: "What are arrays in JavaScript and what methods can you use on them?",
      keywords: ["array", "push", "pop", "map", "filter", "reduce", "length", "index"],
    },
    {
      id: 7,
      question: "What is the DOM and how does JavaScript interact with it?",
      keywords: ["DOM", "document", "element", "querySelector", "getElementById", "modify", "HTML", "manipulation"],
    },
    {
      id: 8,
      question: "Explain how `setTimeout` and `setInterval` work.",
      keywords: ["setTimeout", "setInterval", "delay", "timer", "async", "callback", "milliseconds", "repeat"],
    },
  ],
};

export function scoreAnswer(answer: string, keywords: string[]): number {
  if (!answer.trim()) return 0;
  const lowerAnswer = answer.toLowerCase();
  const matched = keywords.filter((kw) => lowerAnswer.includes(kw.toLowerCase()));
  const ratio = matched.length / keywords.length;
  const score = Math.round(ratio * 10);
  return Math.min(score, 10);
}

export function getPerformanceLevel(score: number): { label: string; color: string; emoji: string } {
  if (score >= 8) return { label: "Excellent", color: "text-emerald-400", emoji: "🏆" };
  if (score >= 6) return { label: "Good", color: "text-cyan-400", emoji: "⭐" };
  if (score >= 4) return { label: "Average", color: "text-yellow-400", emoji: "📈" };
  return { label: "Needs Practice", color: "text-red-400", emoji: "💪" };
}

export function pickRandomQuestions(topic: string, count: number = 5): Question[] {
  const pool = questionBank[topic] || [];
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}
